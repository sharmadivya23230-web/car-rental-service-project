# urls.py
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from .views import register_owner, customer_view, car_status, success_page,login,car_page,create_vehicle,book_car,confirmbook# Import success_page

urlpatterns = [
    path('register/', register_owner, name='register_owner'),
    path('customer/', customer_view, name='customer'),
    path('status/', car_status, name='car_status'),
    path('success/',success_page, name='success_page'),
    path('car_page/',car_page, name='car_page'),
    path('create_vehicle/',create_vehicle, name='create_vehicle'),
    path('book_car/<int:vehicle_id>/',book_car, name='book_car'),
    path('login/',login, name='login'),
    path('confirmbook/',confirmbook, name='confirmbook'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)