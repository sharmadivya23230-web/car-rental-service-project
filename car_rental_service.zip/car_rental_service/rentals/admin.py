

from django.contrib import admin
from .models import VehicleOwner, Vehicle, Booking, Payment

admin.site.register(VehicleOwner)
admin.site.register(Vehicle)
admin.site.register(Booking)
admin.site.register(Payment)
