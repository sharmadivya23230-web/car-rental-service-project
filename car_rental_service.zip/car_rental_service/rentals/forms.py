from django import forms
from .models import VehicleOwner, Booking, customer1,login,Vehicle
from django.core.exceptions import ValidationError
from django.contrib.auth.models import User
class VehicleOwnerForm(forms.ModelForm):
    class Meta:
        model = VehicleOwner
        fields = ['user', 'mobile_number', 'password1', 'vehicle_type', 'vehicle_no']
        user = forms.CharField(max_length=100) # User types their name
        mobile_number = forms.CharField(max_length=15, required=True, label='Mobile Number')
        password1 = forms.CharField(widget=forms.PasswordInput, label='Password')
        vehicle_type = forms.CharField(max_length=100, required=True, label='Vehicle Type')
        vehicle_no = forms.CharField(max_length=20, required=True, label='Vehicle Number')
    
    def clean_user(self):
        user = self.cleaned_data.get('user')
        if not user:
            raise forms.ValidationError("User is required")
        return user

    def clean_mobile_number(self):
        mobile_number = self.cleaned_data.get('mobile_number')
        if not mobile_number:
            raise forms.ValidationError("Mobile number is required")
        return mobile_number

class customer(forms.ModelForm):
    class Meta:
        model = customer1
        fields = ['name','email','mobile_number','password','customeraddress']
        name = forms.CharField(max_length=100) # User types their name
        email = forms.CharField(max_length=15, required=True, label='email')
        mobile_number = forms.CharField(max_length=15, required=True, label='Mobile Number')
        password = forms.CharField(widget=forms.PasswordInput, label='Password')
        customeraddress = forms.CharField(max_length=100, required=True, label='customeraddress')

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['vehicle','customerName','start_date', 'end_date','pickupaddress','dropaddress','total_amount']
    start_date = forms.DateField(widget=forms.SelectDateWidget(years=range(2020, 2030)))
    end_date = forms.DateField(widget=forms.SelectDateWidget(years=range(2020, 2030)))
    def clean_total_amount(self):
        cleaned_data = self.cleaned_data
        start_date = cleaned_data.get('start_date')
        end_date = cleaned_data.get('end_date')

        # Assuming you have a vehicle instance available
        # This can be accessed through a field or passed in the form's constructor
        vehicle = self.instance.vehicle  # Assuming the form instance has a related vehicle
        
        if start_date and end_date:
            # Calculate the days difference
            total_days = (end_date - start_date).days
            if total_days <= 0:
                raise ValidationError("End date must be after the start date.")
            
            # Assuming you get price_per_day from the vehicle object
            price_per_day = vehicle.price_per_day  # Fetch the actual price per day from the Vehicle model
            total_amount = total_days * price_per_day
            return total_amount
        
        return 0

    def clean(self):
        cleaned_data = super().clean()
        
        # Optionally, you can add more validation here if necessary
        
        return cleaned_data
class LoginForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, label="Password")

    class Meta:
        model = User  # Use the User model for authentication
        fields = ['username', 'password']

class Vehicle(forms.ModelForm):
    class Meta:
        model = Vehicle
        fields = ['owner', 'make', 'model', 'year', 'status', 'image','des','price_per_day']
