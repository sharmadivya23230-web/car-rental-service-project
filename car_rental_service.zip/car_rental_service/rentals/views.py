from django.shortcuts import render, redirect
from .forms import VehicleOwnerForm, BookingForm,customer,Vehicle,LoginForm
from .models import Vehicle,customer1,VehicleOwner,Booking
from django.views.generic import TemplateView
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.hashers import check_password
from django.utils import timezone
from django.contrib import messages
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
import logging
from datetime import datetime
from django.contrib.auth.models import User

def register_owner(request):
    if request.method == 'POST':
        form = VehicleOwnerForm(request.POST)
        if form.is_valid():
            form.save()  # Save the form data to the database
            return redirect('success_page')  # Use the correct URL pattern name ('success_page')
    else:
        form = VehicleOwnerForm()
    
    return render(request, 'register_owner.html', {'form': form})

def success_page(request):
    return render(request, 'success.html')

def customer_view(request):
    if request.method == 'POST':
        form = customer(request.POST)
        if form.is_valid():
            form.save()
            return redirect('success_page')
    else:
        form = customer()

    return render(request, 'customer.html', {'form': form})

def success_page(request):
    return render(request, 'success.html')

def book_car(request, vehicle_id):
    # Get the specific vehicle and owner using the IDs
    vehicle = get_object_or_404(Vehicle, id=vehicle_id)
    # Handle form submission
    if request.method == 'POST':
            start_date = request.POST.get('start_date')
            end_date = request.POST.get('end_date')
            pickupaddress = request.POST.get('pickupaddress')
            dropaddress = request.POST.get('dropaddress')
            customerName=request.POST.get('customerName')
            
            if start_date and end_date:
                    start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
                    end_date = datetime.strptime(end_date, "%Y-%m-%d").date()

            # Calculate total amount
            price_per_day = vehicle.price_per_day
            delta = end_date - start_date
            if delta.days > 0:
                total_amount = price_per_day * delta.days
            else:
                total_amount = 0
                
            booking = Booking(
                vehicle=vehicle,
                customerName=customerName,
                start_date=start_date,
                end_date=end_date,
                pickupaddress=pickupaddress,
                dropaddress=dropaddress,
                total_amount=total_amount
            )
            booking.save()
            # Redirect to a confirmation page
            return redirect('confirmbook')
    return render(request, 'book_car.html', {'vehicle': vehicle})

def confirmbook(request):
    return render(request, 'confirmbook.html')

def car_status(request):
    vehicles = Vehicle.objects.all()
    return render(request, 'car_status.html', {'vehicles': vehicles})

class HomePageView(TemplateView):
    template_name = 'home.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['current_year'] = timezone.now().year
        return context

def login(request):
    if request.method == 'POST':
        # Get username and password from form
        username = request.POST.get('user')
        password = request.POST.get('password')

        # Check if user exists in the customer1 model
        try:
            # First, check if it's a customer
            customer = customer1.objects.get(name=username, password=password)
            # If credentials are correct for customer, redirect to the car page
            return redirect('car_page')  # Or a page relevant to customers
        except customer1.DoesNotExist:
            # If not found in customer1, check in the VehicleOwner model
            try:
                vehicle_owner = VehicleOwner.objects.get(user=username, password1=password)
                # If credentials are correct for vehicle owner, redirect to the car page
                return redirect('car_page')  # Or a page relevant to vehicle owners
            except VehicleOwner.DoesNotExist:
                # If not found in either model, show an error message
                messages.error(request, "Invalid username or password.")
                return redirect('login')  # Redirect back to login page

    return render(request, 'login.html')  # Render the login page if GET request

def car_page(request):
    vehicles = Vehicle.objects.all()
    return render(request, 'car_page.html', {'vehicles': vehicles})

def create_vehicle(request):
    if request.method == 'POST':
        # Extract data from request.POST and request.FILES directly
        owner_id = request.POST.get('owner')
        make = request.POST.get('make')
        model = request.POST.get('model')
        year = request.POST.get('year')
        status = request.POST.get('status') == 'True'  # Convert to boolean
        image = request.FILES.get('image')
        des = request.POST.get('des')
        price_per_day = request.POST.get('price_per_day')
        # Manually create the Vehicle instance without validation
        vehicle = Vehicle(
            owner_id=owner_id,
            make=make,
            model=model,
            year=year,
            status=status,
            image=image,
            des=des,
            price_per_day=price_per_day
        )

        # Save the vehicle instance
        vehicle.save()

        # Redirect to a new page after saving
        return redirect('car_page')  # Replace 'car_page' with your actual URL name
    
    else:
        # Display an empty form (GET request)
        form = Vehicle()

    # Fetch all vehicle owners to populate the owner field in the form
    vehicle_owners = VehicleOwner.objects.all()
    return render(request, 'create_vehicle.html', {'form': form, 'vehicle_owners': vehicle_owners})