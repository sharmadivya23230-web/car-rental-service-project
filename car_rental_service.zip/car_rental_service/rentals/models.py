from django.db import models
from django.contrib.auth.models import User

class VehicleOwner(models.Model):
    user = models.CharField(max_length=100)
    mobile_number = models.CharField(max_length=15)
    password1 = models.CharField(max_length=100)
    vehicle_type = models.CharField(max_length=100)
    vehicle_no = models.CharField(max_length=15)
    def __str__(self):
        return self.user

class Vehicle(models.Model):
    owner = models.ForeignKey('VehicleOwner', on_delete=models.CASCADE)
    make = models.CharField(max_length=100)
    model = models.CharField(max_length=100)
    year = models.IntegerField()
    status = models.BooleanField(default=True)  # True for Available, False for Unavailable
    image = models.ImageField(upload_to='vehicles/', blank=True, null=True)
    des = models.CharField(max_length=255, null=True, blank=True)
    price_per_day = models.CharField(max_length=10,null=True, blank=True)
    def __str__(self):
        return f'{self.make} {self.model} ({self.year})'

class Booking(models.Model):
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE)
    customerName = models.CharField(max_length=100, null=False, default="Anonymous")
    start_date = models.DateField()
    end_date = models.DateField()
    pickupaddress = models.CharField(max_length=100, null=True, blank=True)
    dropaddress = models.CharField(max_length=100, null=True, blank=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)

class Payment(models.Model):
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_date = models.DateField(auto_now_add=True)

class customer1(models.Model):
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=50)
    mobile_number = models.CharField(max_length=15)
    password = models.CharField(max_length=10)
    customeraddress = models.CharField(max_length=100)
    def __str__(self):
        return self.name

class login(models.Model):
    user = models.CharField(max_length=100)
    password = models.CharField(max_length=15)