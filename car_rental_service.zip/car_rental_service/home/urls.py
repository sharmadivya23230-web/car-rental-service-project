from django.conf import settings
from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from rentals.views import HomePageView
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('rentals.urls')),  # Assuming you have a rentals.urls for handling the registration
    path('', HomePageView.as_view(), name='home'),  # Root URL pattern
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)